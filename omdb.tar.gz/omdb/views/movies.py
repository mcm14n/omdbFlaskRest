import logging
import re
import json
import requests
from flask_restful import reqparse, abort, Api, Resource

LOGGER = logging.getLogger(__name__)

APIKEY = "5974fe11"

ERR_MESSAGE = "Unable to Fetch Movie"
CODES = dict(
    OK=200,
    BAD_REQUEST=400
)


def fetch_request(movie):
    mv = re.sub("\s", "+", movie)
    return f"http://www.omdbapi.com/?t={mv}&apikey={APIKEY}"


class FetchMovie(Resource):
    """ Endpoint /movie/fetch to get movie from omdb api """

    def get(self, movie):
        try:
            LOGGER.info("-- GET -- /movie/fetch")
            omdb_request = requests.get(fetch_request(movie)).json()
            resp = {
                "movie": omdb_request
            }
            if resp["movie"]:
                return resp
            raise Exception
        except (IndexError, Exception):
            abort(CODES["BAD_REQUEST"], ERR_MESSAGE)
