import json
from flask import Flask, make_response
from simplexml import dumps
from flask_cors import CORS
from flask_restful import Resource, Api

from . import movies


def output_xml(data, code, headers=None):
    """Makes a Flask response with a XML encoded body"""
    resp = make_response(dumps({'response': data}), code)
    resp.headers.extend(headers or {})
    return resp


app = Flask(__name__)
cors = CORS(app, resources={r"*": {"origins": "*"}})
api = Api(app, default_mediatype='application/xml')
api.representations['application/xml'] = output_xml


def add_route(view, route):
    api.add_resource(view, route)


routes = [(movies.FetchMovie, "/movie/fetch/<movie>")]

for route in routes:
    view, path = route
    add_route(view, path)
