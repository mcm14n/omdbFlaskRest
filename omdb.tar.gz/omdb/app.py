#!/bin/env python

from views import app
from config.app import HOST, PORT


class BaseConfig(object):
    DEBUG = True
    SECRET_KEY = ""
    HOST = HOST
    PORT = PORT


class Develop(BaseConfig):
    pass


if __name__ == '__main__':
    dev = Develop()
    app.run(host=dev.HOST, port=dev.PORT, debug=dev.DEBUG)
